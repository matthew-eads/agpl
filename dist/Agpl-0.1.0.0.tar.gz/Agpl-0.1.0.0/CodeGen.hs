module CodeGen where

import Agpl_syntax
import Parser
import Language.Haskell.TH
import Language.Haskell.TH.Quote
import Language.Haskell.TH.Syntax
import Debug.Trace
nilD = (DataD [] (mkName "NULL") [] [NormalC (mkName "NULL") []] [])

makeAGPLDecs :: Game -> Q [Dec]
makeAGPLDecs (Game (id, gs, m, ivf, pmf, ocf, is, p, cd)) = 
    (trace id (do {
      test <- testD;
      
      gsdecs <- (trace (show test) (gamestateDec gs));
      initStateDecs <- initStateDec is;
      move <- moveDec m;
      player <- playerDec p;
      isValid <- isValidDec ivf;
      return (gsdecs ++ initStateDecs ++ move ++ player ++ isValid);
    }))

makeAGPLDecs _ = [d| bar y = y * y|]

gamestateDec :: GameState -> Q [Dec]
gamestateDec gs =
    let bdec = (trace ("b: " ++ (show (board gs))) (board gs)) 
        pdec = (trace ("p: " ++ (show (piece gs))) (piece gs))
        hdec = (trace ("h: " ++ (show(hand gs))) (hand gs))
        tdec = (trace ("t: " ++ (show (turn gs))) (turn gs))
    in do {
         return (foldl (\acc -> \x -> if x == nilD then acc else (x:acc)) 
                [] [bdec, pdec, hdec, tdec]) 
       }
      
testD :: Q [Dec]
testD = [d| data A = A{b :: Int, c :: Char} |]
initStateDec :: InitState -> Q [Dec]
initStateDec is = 
    do {
      let board = (boardInit is) in
      let turn = ValD (VarP (mkName "turn")) (NormalB (turnInit is)) [] in
      let bDec = ValD (VarP (mkName "boardInitF")) (NormalB board) [] in
      return [bDec, turn];
    }

isValidDec :: IsValidFun -> Q [Dec]
isValidDec (IsValidFun e) =
    let f = ValD (VarP (mkName "isValid")) (NormalB (e)) []
    in do {return [f]}
      

moveDec :: Move -> Q [Dec]
moveDec (Move d) = do {return [d]}

playerDec :: Player -> Q [Dec]
playerDec (Player d) = do {return [d]}

customDataDec :: CustomDataType -> Q [Dec]
customDataDec (CustomDataType d) = do {return [d]}
